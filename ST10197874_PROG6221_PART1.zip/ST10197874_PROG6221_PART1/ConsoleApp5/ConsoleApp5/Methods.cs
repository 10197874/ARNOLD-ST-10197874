﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ConsoleApp5
{
     class Methods : Program 
    {

        
          private int sentinel;
          private int i = 1;
          private double sum = 0;
          int Answer4 = 0; 

        //Array to store all the user's Details
        static List<string> name = new List<string>();
        static List<string> unitMeasure = new List<string>();
        static List<string> step = new List<string>();
        static List<double> quantity = new List<double>();
        static List<double> NewDetail = new List<double>();
        static List<double> OldDetail = new List<double>();





        // Prompt the user to enter the details for each ingredient
        public void Details()
        {
            
           try { 
                Console.Write("Enter Number of ingredients : ");
                int sentinel = Convert.ToInt32(Console.ReadLine());
                // add = add + quatity;
                for (int i = 0; i < sentinel; i++) 
                {
                    Console.WriteLine("******************************************");

                    Console.Write("Enter ingredient name : ");                   
                    string ingname = Console.ReadLine();

                    name.Insert(i, ingname);
                    Console.Write("Enter quantity number : ");
                    int quan = Convert.ToInt32(Console.ReadLine());
                    quantity.Insert(i, quan);
                    Console.Write("Enter Unit of measurement : ");
                    string Unit= Console.ReadLine();
                    unitMeasure.Insert(i, Unit);

                   

                    sum = sum + quantity[i];
                    i++;
                    Console.WriteLine("******************************************");
                    Console.WriteLine("");
                    Console.WriteLine("");
                }


                // Prompt the user to enter the number of steps
                Console.WriteLine("STEPS");
                    Console.WriteLine("******************************************");

                    Console.Write("Enter Number of Steps : ");
                    int sentinel1 = Convert.ToInt32(Console.ReadLine());
                    

                    Console.WriteLine("******************************************");
                     Console.WriteLine("Enter steps for each ingredient");
                for (int j = 0; j < sentinel1; j++)
                    {
                       
                        Console.Write((j+1) + ". ");
                        string stepIng = Console.ReadLine();
                        step.Insert(j, stepIng);
                       
                        
                        Console.WriteLine("******************************************");
                    }
                   
                
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
                Details();
            }

            Program.MENU();

        }

        // Display the ingredients and quantities
        public void Display()
        {
            for (int d = 0; d < name.Count; d++)
            {
                Console.WriteLine("INGREDIENTS");
                Console.WriteLine("******************************************");
                Console.WriteLine(d + 1 + " . " + quantity[d] + " " + unitMeasure[d] + " of " + name[d]);
            }

            Console.WriteLine("");
            Console.WriteLine("Steps");
            Console.WriteLine("******************************************");
            for (int d = 0; d < name.Count; d++)
            {
                Console.WriteLine(d + 1 + " . " + step[d]);
            }

            Program.MENU();

        }
        // Multiply all the quantities by the scaling factor
        public void Quantity1()
        {
            Console.WriteLine("Scale by what Factor ");
            Console.WriteLine("1. 0.5 (half)");
            Console.WriteLine("2. 2 (double)");
            Console.WriteLine("3. 3 (Triple) ");
            try
            {
                Console.Write("Enter number : ");
                int Answer4 = Convert.ToInt32(Console.ReadLine());

                if (Answer4 == 1)
                {
                    for (int d = 0; d < (quantity.Count + 1); d++)
                    {
                        Console.WriteLine("INGREDIENTS");
                        Console.WriteLine("******************************************");
                        quantity[d] *= 0.5;
                        // NewDetail[d] = quantity[d] * 0.5;
                        Console.WriteLine(d + 1 + " . " + (quantity[d]) + " " + unitMeasure[d] + " of " + name[d]);
                    }
                }
                else if (Answer4 == 2)
                {
                    for (int d = 0; d < (step.Count + 1); d++)
                    {
                        Console.WriteLine("INGREDIENTS");
                        Console.WriteLine("******************************************");
                        quantity[d] *= 2;
                        Console.WriteLine(d + 1 + " . " + (quantity[d]) + " " + unitMeasure[d] + " of " + name[d]);
                    }

                }
                else if (Answer4 == 3)
                {
                    for (int d = 0; d < (step.Count + 1); d++)
                    {
                        Console.WriteLine("INGREDIENTS");
                        Console.WriteLine("******************************************");
                        quantity[d] *= 3;
                        Console.WriteLine(d + 1 + " . " + (quantity[d]) + " " + unitMeasure[d] + " of " + name[d]);
                    }

                }
            }
            catch (Exception e)
            {
               
                Quantity1();
            }

            Program.MENU();
        }

        // taking the new quantities back to the Originall
        public void Reset()
        {
            
                
                if (Answer4 == 1)
                {
                    for (int w = 0; w < (step.Count + 1); w++)
                    {

                        Console.WriteLine("INGREDIENTS");
                    Console.WriteLine("******************************************");
                    quantity[w] /= 0.5;
                   // OldDetail[w] = NewDetail[w] / 0.5;
                    Console.WriteLine(w + 1 + " . " + (quantity[w]) + " " + unitMeasure[w] + " of " + name[w]);
                    }
                }
                else if (Answer4 == 2)
                {
                    for (int w = 0; w < (step.Count + 1); w++)
                    {
                        Console.WriteLine("INGREDIENTS");
                    Console.WriteLine("******************************************");
                    quantity[w] /= 2;
                    Console.WriteLine(w + 1 + " . " + (quantity[w]) + " " + unitMeasure[w] + " of " + name[w]);
                    }

                }
                else if (Answer4 == 3)
                {
                    for (int w = 0; w < (step.Count + 1); w++)
                    {
                        Console.WriteLine("INGREDIENTS");
                    Console.WriteLine("******************************************");
                    quantity[w] /= 3;
                    Console.WriteLine(w + 1 + " . " + (quantity[w]) + " " + unitMeasure[w] + " of " + name[w]);
                    }


                }

            
            Console.WriteLine("DATA completly Reset !!!");
            Console.WriteLine("******************************************");
            Console.WriteLine(" ");

            Program.MENU();
        }
        // Clear all the data in each array
        public void clear()
        {
            name.Clear();
            unitMeasure.Clear();
            name.Clear();
           
            step.Clear();
            quantity.Clear();
            

            Console.WriteLine("DATA ERASED SUCCESSFULLY!!!!");
            Console.WriteLine("******************************************");

            Program.MENU();
        }



    };

        
        
      
    }
   

