﻿using System.Collections.Generic;
using ConsoleApp5;

internal class Program
{

   


    public static void Main(string[] args)
    {
       
        MENU();

    }
    //Main Menu of the application
    public static void MENU()
    {
        Methods Recipe = new Methods();

        Console.WriteLine("MENU");
        Console.WriteLine("******************************************");
        Console.WriteLine("1. Enter Recipe ");
        Console.WriteLine("2. Display Recipe ");
        Console.WriteLine("3. Scale quantity amount");
        Console.WriteLine("4. Reset quantity amount");
        Console.WriteLine("5. Clear the current recipe");
        Console.WriteLine("");
        Console.WriteLine("");
        Console.Write("Enter number : ");
        int Answer1 = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("******************************************");
        Console.WriteLine("");

        switch (Answer1)
        {
            case 1:
                Recipe.Details();
                break;

            case 2:
                Recipe.Display();
                break;

            case 3:
                Recipe.Quantity1();
                break;

            case 4:
                Recipe.Reset();
                break;

            case 5:
                Recipe.clear();
                break;

        }
    }
   
   
    

};







